import { useState } from 'react';
import AuthModal from './AuthModal';

interface NavButtonProps {
  onClick: () => void;
  className: string;
  children: React.ReactNode;
}

interface AuthButtonsProps {
  onAuthClick: () => void;
}

interface LogoProps {
  onClick?: () => void;
}

function NavButton({ onClick, className, children }: NavButtonProps) {
  return (
    <button onClick={onClick} className={className}>
      {children}
    </button>
  );
}

function NavLogo({ onClick }: LogoProps) {
  return (
    <div>
      <NavButton 
        onClick={onClick || (() => {})}
        className="text-white font-semibold text-lg flex items-center gap-2 hover:text-gray-300 transition-colors"
      >
        <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
          <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
        </svg>
        Home
      </NavButton>
    </div>
  );
}

function AuthButtons({ onAuthClick }: AuthButtonsProps) {
  const buttons = [
    { text: 'Sign in', className: 'text-gray-300 px-3 py-1.5 rounded border border-gray-600 hover:text-white hover:border-gray-500 transition-all' },
    { text: 'Sign up', className: 'bg-green-600 text-white px-3 py-1.5 rounded hover:bg-green-700 transition-colors' }
  ];

  return (
    <div className="flex items-center gap-3">
      {buttons.map((button) => (
        <NavButton
          key={button.text}
          onClick={onAuthClick}
          className={button.className}
        >
          {button.text}
        </NavButton>
      ))}
    </div>
  );
}

export default function Navbar() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const handleAuthClick = () => setIsAuthModalOpen(true);
  const handleCloseModal = () => setIsAuthModalOpen(false);
  const handleHomeClick = () => {
    console.log('Navigate to home');
  };  return (
    <>
      <nav className="bg-gray-900 border-b border-gray-700 py-3 px-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <NavLogo onClick={handleHomeClick} />
          <AuthButtons onAuthClick={handleAuthClick} />
        </div>
      </nav>

      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={handleCloseModal} 
      />
    </>
  );

		//da implementare la logica per il login e la registrazione e il cambio	di stato della nabvar(cambio icone/bottoni successive al	login)
}